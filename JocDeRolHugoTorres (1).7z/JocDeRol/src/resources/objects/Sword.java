package resources.objects;

public class Sword extends Items{
    public Sword() {this.setIcon("src/resources/images/dungeon/sword.png");}
}
