package resources.objects;

public class Mitra extends Items{
    public Mitra() {this.setIcon("src/resources/images/dungeon/mitra.png");}
}
