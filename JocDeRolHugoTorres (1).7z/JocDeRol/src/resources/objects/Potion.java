package resources.objects;

public class Potion extends Items{
    public Potion() {this.setIcon("src/resources/images/dungeon/potion.png");}
}
