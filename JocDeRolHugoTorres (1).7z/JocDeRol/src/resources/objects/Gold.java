package resources.objects;

public class Gold extends Items{
    public Gold() {this.setIcon("src/resources/images/dungeon/coin.png");}
}
